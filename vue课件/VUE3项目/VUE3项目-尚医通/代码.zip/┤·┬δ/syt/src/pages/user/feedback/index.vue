<template>
    <div>
        意见反馈
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>
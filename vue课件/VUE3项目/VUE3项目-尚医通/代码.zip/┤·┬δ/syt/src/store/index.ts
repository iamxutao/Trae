import { createPinia } from 'pinia';
//对外暴露大仓库
export default createPinia();